package cdd.desk.model.card;

public enum CardColor{
	 Diamond,//方块
	 Club,//梅花
	 Heart,//红桃
	 Spade//黑桃
}