package cdd.desk.model.card;
/**
 * @author AhaLims
 */

public enum CardsType {
	danzhang,//单牌
	yidui,//两张相等的一对牌
	sanzhang,//3张一样的牌
	zashun,//杂顺
	wutonghua,//五同花 注意必须是五张牌 必须是同花色的
	sandaier,//三带二
	sidaiyi,//四带一
	tonghuashun,//同花顺
	card0//不能出牌
}