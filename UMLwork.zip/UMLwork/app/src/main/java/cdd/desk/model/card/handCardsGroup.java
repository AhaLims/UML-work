//管理手牌 并更新牌 判断牌是不是出完了
//每次出牌之后都需要调用

//貌似这个部分放到 Rolemanager去了
package cdd.desk.model.card;

import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.List;

public class handCardsGroup extends CardsGroup{

}