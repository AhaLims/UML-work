package cdd.bgm.contract;

import android.view.View;

public interface bgmContract {
    interface Model {

    }

    interface View {

    }

    interface Presenter {
    }
}
