package cdd.bgm.model;

import cdd.bgm.contract.bgmContract;

public class bgmModel implements bgmContract.Model {

}
