package cdd.bgm.presenter;

import cdd.bgm.contract.bgmContract;

public class bgmPresenter implements bgmContract.Presenter {
    
}
