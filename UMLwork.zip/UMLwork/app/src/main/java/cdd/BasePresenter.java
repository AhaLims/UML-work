package cdd;

public interface BasePresenter {

    void start();

}
