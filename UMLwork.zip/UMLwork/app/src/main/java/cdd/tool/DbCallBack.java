package cdd.tool;

public interface DbCallBack {
    interface RankCallBack {
        public void dispalyRank(String name, int score, int rank);
    }
}
