package cdd.menu.model;

import cdd.menu.contract.menuContract;

public class menuModel implements menuContract.Model {

}
