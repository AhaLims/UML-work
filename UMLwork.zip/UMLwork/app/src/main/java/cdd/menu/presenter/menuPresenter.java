package cdd.menu.presenter;

import cdd.menu.contract.menuContract;

public class menuPresenter implements menuContract.Presenter {
}
