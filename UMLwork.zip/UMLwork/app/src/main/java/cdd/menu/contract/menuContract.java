package cdd.menu.contract;

public interface menuContract {
    interface Model {
    }

    interface View {

    }

    interface Presenter {
    }
}
